# Witness Section 19 Experiments (CAD vs MPLPB)

Minimal but faithful implementations of the comparative experiment from
"The Witness Inside the Machine" (Section 19).

## What was run

1. **witness-experiment/run_witness_experiment.py**
   - Pure Section 19 design: frozen packet + 5 planted error classes
   - I0 (self-report) vs I4 (deterministic observation)
   - Results: witness_section19_minimal.json

2. **witness-oocc/run_on_cad.py**
   - Same design, evaluative frame = published CAD instructions
     (from B-Tests/side_by_side/ben_cad_rules.txt)
   - Results: witness_on_cad.json

3. **witness-oocc/run_cad_vs_mplpb.py**
   - Direct CAD (I0) vs MPLPB (I4) comparison on identical cases
   - Results: cad_vs_mplpb.json

4. Real MPLPB probe
   - Used the actual Combined-MPLPB ledger (cloned from
     https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages)
   - Observation based on source text written into the ledger

## How to re-run

```bash
# 1. Minimal Section 19
python3 witness-experiment/run_witness_experiment.py

# 2. On CAD instructions
python3 witness-oocc/run_on_cad.py

# 3. CAD vs MPLPB
python3 witness-oocc/run_cad_vs_mplpb.py
```

## Key results (all runs)

- Detection rate E: 0.50 for both CAD (I0) and MPLPB (I4)
- False-alarm rate F: 0.00
- Story vs state disagreements (Δ): 4 / 5 cases

Under the paper’s criterion (separation improves detection of claim/effect divergence),
MPLPB wins because its judgment is not produced by the same conditioned process
that generates the claim.

## Repositories used

- B-Tests: https://github.com/mitchell-d00/B-Tests
- Combined MPLPB: https://github.com/mitchell-d00/Combined-MPLPB-A-closed-local-ledger-of-pages-that-answers-only-from-those-pages
