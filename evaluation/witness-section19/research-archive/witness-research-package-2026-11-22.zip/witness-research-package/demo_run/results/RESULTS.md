# Witness-Independence Experiment: results

Frozen run root hash: `a87a121bdeccbc6371ab1ca24751df4f0ca5c62bcc9974ae2a664e93a307c9dd`

E = detection of planted-incorrect states. F = false alarms on correct states. J = E − F (discrimination). ABSTAIN counts as neither.

| Judge | Level | E | E 95% CI | F | F 95% CI | J | Coverage |
|---|---|---|---|---|---|---|---|
| I0_self_assessment | I0 | 0.0% | 0–4% | 0.0% | 0–9% | +0.00 | 100.0% |
| I1_same_frame | I1 | 42.0% | 33–52% | 0.0% | 0–9% | +0.42 | 100.0% |
| I4_retained_state | I4 | 80.0% | 71–87% | 0.0% | 0–9% | +0.80 | 100.0% |

## Reject rate by case class

Rows marked (correct) should be near 0%; the rest should be near 100%.

| Class | I0_self_assessment | I1_same_frame | I4_retained_state |
|---|---|---|---|
| supported_execution (correct) | 0.0% | 0.0% | 0.0% |
| correct_refusal (correct) | 0.0% | 0.0% | 0.0% |
| false_completion | 0.0% | 60.0% | 100.0% |
| inherited_state_conflict | 0.0% | 0.0% | 100.0% |
| prohibited_effect | 0.0% | 50.0% | 100.0% |
| false_refusal | 0.0% | 100.0% | 100.0% |
| interpretive_misattribution | 0.0% | 0.0% | 0.0% |

## Paired comparisons on planted-incorrect cases (exact McNemar)

| A | B | caught by A only | caught by B only | p |
|---|---|---|---|---|
| I0_self_assessment | I1_same_frame | 0 | 42 | 4.55e-13 |
| I0_self_assessment | I4_retained_state | 0 | 80 | 1.65e-24 |

Story vs. state: 80 planted-incorrect cases where the runtime's self-assessment said PASS and the retained state said FAIL.
